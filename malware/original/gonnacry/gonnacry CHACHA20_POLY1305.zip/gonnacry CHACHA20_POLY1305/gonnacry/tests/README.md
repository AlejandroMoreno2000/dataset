# Test enviroment 

This directory does not affect your computer, 
If u want to test the ransomware, here is the place

Inside the files/ folder, there is some files that will be Encrypted/Decrypted

# Compiling

    sh comp.sh # to compile the Encryptor
    sh decryptorcomp.sh to compile the Decryptor
