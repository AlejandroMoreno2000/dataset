#include"struct.h"
#include<stdlib.h>
#include<string.h>
#include<stdio.h>

/**
 * This function will append the path, key and iv to the l(List).
 * It's a simple Linked List.
 * @param l -> type = List
 * @param file_path -> type = char * (String)
 */
void append(List **l, char *file_path, char *key, char *iv){
    List *aux = (List*)malloc(sizeof(List));
    if (!aux) return;  // Verifica que la asignación fue exitosa

    // Inicializa aux para evitar comportamiento indefinido
    aux->prox = NULL;
    for (int i = 0; i < 3; i++) {
        aux->info[i] = NULL;  
    }

    int len = strlen(file_path);
    aux->info[2] = (char*)malloc(sizeof(char) * (len + 1));
    if (aux->info[2]) {
        strcpy(aux->info[2], file_path);
    }

    if (key != NULL && iv != NULL) {
        aux->info[0] = (char *)malloc(sizeof(char) * 33);
        aux->info[1] = (char *)malloc(sizeof(char) * 17);
        if (aux->info[0] && aux->info[1]) {
            strcpy(aux->info[0], key);
            strcpy(aux->info[1], iv);
        }
    }

    if (*l == NULL) {
        *l = aux;
        (*l)->size = 0;  // Asigna el tamaño después de asignar *l a aux
    } else {
        aux->prox = *l;
        *l = aux;
    }

    (*l)->size++;  // Incrementa el tamaño de la lista
}

/**
 * This function destroys the l(List).
 * releasing the memory with free().
 * @param l -> type = List
 */
void destroy(List **l){
    List *aux;
    while(*l != NULL){
        aux = *l;
        *l = aux->prox;
        
        for(int i = 0; i < 3; i++){
            free(aux->info[i]);  // Libera la memoria asignada
        }

        free(aux);
    }
}

/**
 * This function print all the path's, key's and iv's of the l(List), only used for debugging.
 * @param l -> type = List
 */
void print(List *l){
    while(l != NULL){
        if (l->info[0]) {
            printf("KEY = %s IV = %s PATH = %s\n", l->info[0], l->info[1], l->info[2]);
        } else {
            printf("%s\n", l->info[2]);
        }
        l = l->prox;
    }
}

/**
 * This function return the length of the l(List).
 * @param l -> type = List
 * @return -> type = integer
 */
int length(List *l){
    return l->size;
}

