mkdir debug
mkdir release
cp prompt.txt debug/.
cp prompt.txt release/.
